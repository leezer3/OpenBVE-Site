Glow light textures modified from originals created by Michelle in the OpenBVE project.
openbve.trainsimcentral.co.uk
