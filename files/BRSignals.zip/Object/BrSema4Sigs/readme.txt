BrSema4Sigs - working semaphore signals for BVE4
================================================

Release 07.06


Copyrights
==========

(c) S.Gathercole 2004-5

except rung.bmp, post.bmp, post4.bmp (c) Anthony Bowden


See BrSema4.htm for details of contents and permitted use.